// jshint ignore: start
// jscs: disable
ace.define("ace/snippets/clickhouse",["require","exports","module"], function(require, exports, module) {
    "use strict";

    exports.snippets = [
    ];

    exports.scope = "clickhouse";
});